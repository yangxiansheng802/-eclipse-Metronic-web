
function init(){
    $.ajax({
   url:'ShowAllServlet',
   type:'post',
   data:{
       table:'tc',
       tno:$.session.get('snumber')
    },
   dataType:'json',
   success:function(data){
	   $("#tcbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + item.tno + "</td>";					
		tr += "<td>" + item.tcno + "</td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs black' onclick='DeleteUser("+this.tcno+")' ><i class='fa fa-trash-o'></i> 删除 </a></td></td>";
		tr += "</tr>";
		//alert(item.snumber);
		$("#tcbody").append(tr);
	
	   })
    }
   })
}
	var addform = $('#Addform');
	var error2 = $('.alert-danger', addform);
	var success2 = $('.alert-success', addform);
	// validation using icons
	var handleAddValidation = function() {
		// for more info visit the official plugin documentation: 
		// http://docs.jquery.com/Plugins/Validation

		

		addform.validate({
			errorElement : 'span', //default input error message container
			errorClass : 'help-block help-block-error', // default input error message class
			focusInvalid : false, // do not focus the last invalid input
			ignore : "", // validate all fields including form hidden input
			rules : {
				Cno : {
					required : true,
					minlength : 1,
					maxlength : 3
				},
				Cname : {
					required : true,
					minlength : 2,
					maxlength : 15
				},
				Cpno : {
					required : false,
					minlength : 1,
					maxlength : 3
				},
				Credit : {
					required : true,
					minlength : 1,
					maxlength : 1
				},
				Tname : {
					required : true,
					minlength : 2,
					maxlength : 4
				}
			},

			invalidHandler : function(event, validator) { //display error alert on form submit              
				success2.hide();
				error2.show();
				Metronic.scrollTo(error2, -200);
			},

			highlight : function(element) { // hightlight error inputs
				$(element).closest('.form-group').removeClass("has-success").addClass('has-error'); // set error class to the control group   
			},

			unhighlight : function(element) { // revert the change done by hightlight
				$(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
			},

			success : function(label) {
				label.closest('.form-group').removeClass('has-error'); // set success class to the control group
			},

			submitHandler : function(form) {
				success2.show();
				error2.hide();
				//form[0].submit(); // submit the form			
					add();

			}
		});

	}
	function OpenAddForm() {
		$('#Addform')[0].reset();
		success2.hide();
		error2.hide();
		$('.form-group').removeClass('has-error');
		$('.help-block-error').remove();
		$("#addmodalt").modal("show");
	}
	function add() {
		var tno=$.session.get('snumber');
		var postData = $("#Addform").serialize()+"&table=c"+"&Tno="+tno;
		$.post("RegServlet",postData,function(data) {
			if (data == "1") {
				$('#addmodalt').modal('hide');
				bootbox.alert("增设成功");
				init();
			} else
				//alert("注册失败");
				bootbox.alert("增设失败!");
		}, "json");
	}
	function DeleteUser(cno) {
		//var tr = e.parentNode.parentNode;
        //var Snumber=tr.cells[1].innerText;
		bootbox.confirm({
			message : "您真的要删除此课程?",
			title : "询问？",
			callback : function(result) {
				if (result == true) {
					$.get("DeleteServlet?cno=" + cno+"&table=c", function(data) {
						if (data > 0) {
							bootbox.alert("删除成功!");
							//createTable();
							init();
						} else
							//alert("删除失败");
							bootbox.alert("删除失败!");
					});
				}
			},
			buttons : {
				confirm : {
					label : '是',
					className : 'btn-success'
				},
				cancel : {
					label : '否',
					className : 'btn-danger'
				}
			},
		});
	}
	jQuery(document).ready(function() {
		init();
		handleAddValidation();
	});


