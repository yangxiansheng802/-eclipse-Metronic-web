function showuserlist() {
	
	$('#userlistTable').DataTable( {
		ajax: {
	        url: 'FindServlet',
	        dataSrc: ''
	    },
	    columns: [
	    	{ data: 'id' },
	        { data: 'username' },
	        { data: 'usertype' },
	        { data: 'usertrue' },
	        { data: 'email' },
	        { data: 'tel' },
	        { data:'company' }
	    ]
	} );	
}
function init(){
    $.ajax({
   url:'ShowAllServlet',
   type:'post',
   data:{
       table:'loginsheet'
    },
   dataType:'json',
   success:function(data){
	   $("#userbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + (i+1) + "</td>";	
		tr += "<td>" + item.snumber + "</td>";					
		tr += "<td>" + item.username + "</td>";
		tr += "<td>" + item.usertype + "</td>";
		tr += "<td>" + item.iphone + "</td>";
		tr += "<td>" + item.company + "</td>";
		tr += "<td>" + item.emailbox + "</td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs purple' onclick='OpenEditForm(this)'><i class='fa fa-edit'></i> 修改 </a></td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs black' onclick='DeleteUser(this)' ><i class='fa fa-trash-o'></i> 删除 </a></td></td>";
		tr += "</tr>";
		//alert(item.snumber);
		$("#userbody").append(tr);
	
	   })
    }
   })
}
	var isAddOrEdit = "add";
	function showusers() {
		alert("123");
		$("#userbody").html("");
		$.getJSON("FindServlet?search="+$("#search").val()+"&table=loginsheet", function(data) {
			$.each(data, function(i) {
				// alert(this.id);
				var tr = "<tr class=\"\" >";
				tr += "<td>" + (i + 1) + "</td>";				
				tr += "<td>" + this.snumber + "</td>";
				tr += "<td>" + this.username + "</td>";
				tr += "<td>" + this.usertype + "</td>";
				tr += "<td>" + this.iphone + "</td>";
				tr += "<td>" + this.company + "</td>";
				tr += "<td>" + this.emailbox + "</td>";
				tr += "<td><a href='javascript:;' class='btn default btn-xs purple'  onclick='OpenEditForm(" + this.Snumber + ")'>";
				tr += "<i class='fa fa-edit'></i> 编辑 </a></td>";
				tr += "<td><a href='javascript:;' class='btn default btn-xs black'  onclick='DeleteUser(" + this.Snumber + ")'  >";
				tr += "<i class='fa fa-trash-o'></i>删除 </a></td>";
				tr += "</tr>";
				$("#userbody").append(tr);
			});
		});
	}
	var addform = $('#Addform');
	var error2 = $('.alert-danger', addform);
	var success2 = $('.alert-success', addform);
	// validation using icons
	var handleAddValidation = function() {
		// for more info visit the official plugin documentation: 
		// http://docs.jquery.com/Plugins/Validation

		

		addform.validate({
			errorElement : 'span', //default input error message container
			errorClass : 'help-block help-block-error', // default input error message class
			focusInvalid : false, // do not focus the last invalid input
			ignore : "", // validate all fields including form hidden input
			rules : {
				Snumber : {
					required : true,
					minlength : 8,
					maxlength : 16
				},
				password : {
					required : true,
					minlength : 8,
					maxlength : 16
				},
				repassword : {
					required : true,
					minlength : 8,
					maxlength : 16
				},
				username : {
					required : true,
					minlength : 2,
					maxlength : 4
				},
				mailbox : {
					required : true,
					email : true
				},
				iphone : {
					required : true,
					minlength : 8,
					maxlength : 13
				},
				company : {
					required : true,
					minlength : 2,
					maxlength : 16
				}
			},
			messages : {
				company : {
					required : "请输入单位名称",
					minlength : "最小8个字符",
					maxlength : "最大16个字符"
				}
			},

			invalidHandler : function(event, validator) { //display error alert on form submit              
				success2.hide();
				error2.show();
				Metronic.scrollTo(error2, -200);
			},

			highlight : function(element) { // hightlight error inputs
				$(element).closest('.form-group').removeClass("has-success").addClass('has-error'); // set error class to the control group   
			},

			unhighlight : function(element) { // revert the change done by hightlight
				$(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
			},

			success : function(label) {
				label.closest('.form-group').removeClass('has-error'); // set success class to the control group
			},

			submitHandler : function(form) {
				success2.show();
				error2.hide();
				//form[0].submit(); // submit the form
				if (isAddOrEdit == 'add') {
					add();
				} else {
					edit();
				}

			}
		});

	}
	function OpenAddForm() {
		isAddOrEdit = 'add';//新增对话框标识  
		$('#Addform')[0].reset();
		success2.hide();
		error2.hide();
		$('.form-group').removeClass('has-error');
		$('.help-block-error').remove();
		$("#addmodal").modal("show");
	}
	function add() {
		var postData = $("#Addform").serialize()+"&table=loginsheet";
		//alert(postData);
		$.post("RegServlet",postData,function(data) {
			if (data == "1") {
				$('#addmodal').modal('hide');
				bootbox.alert("注册成功");
				init();
			} else
				//alert("注册失败");
				bootbox.alert("用户号重复，注册失败!");
		}, "json");
	}
	function edit() {
		var postData = $("#Addform").serialize()+"&table=loginsheet";
		//alert(postData);
		$.post("UpdateServlet", postData, function(data) {
			if (data == "1") {
				$('#addmodal').modal('hide');	
				bootbox.alert("修改成功");
				init();
			} else
				bootbox.alert("学号不能改变，修改失败!");
		}, "json");
	}

	function OpenEditForm(e) {
        var tr = e.parentNode.parentNode;
        var Snumber=tr.cells[1].innerText; 
		isAddOrEdit = 'edit';//新增对话框标识  
		$('#Snumber').val(Snumber);
		$('#Addform')[0].reset();
		success2.hide();
		error2.hide();
		$('.form-group').removeClass('has-error');
		$('.help-block-error').remove();
		$('#addmodal').modal('show');

		$.getJSON("FindServlet?Snumber=" + Snumber+"&table=loginsheet", function(data) {
			//alert(data)
			$.each(data, function(i) {
			
				if (i == 0) {
					$('#usertype').val(this.usertype); 
					$('#Snumber').val(this.snumber);
					$('#password').val(this.password);
					$('#repassword').val(this.password);
					$('#username').val(this.username);
					$('#iphone').val(this.iphone);
					$('#company').val(this.company);
					$('#mailbox').val(this.emailbox);
				}
			});
		});
	}
	function DeleteUser(e) {
		var tr = e.parentNode.parentNode;
        var Snumber=tr.cells[1].innerText;
		bootbox.confirm({
			message : "您真的要删除此用户?",
			title : "询问？",
			callback : function(result) {
				if (result == true) {
					$.get("DeleteServlet?Snumber=" + Snumber, function(data) {
						if (data > 0) {
							bootbox.alert("删除成功!");
							//createTable();
							init();
						} else
							//alert("删除失败");
							bootbox.alert("删除失败!");
					});
				}
			},
			buttons : {
				confirm : {
					label : '是',
					className : 'btn-success'
				},
				cancel : {
					label : '否',
					className : 'btn-danger'
				}
			},
		});
	}
	function setUserType(value) {
		var radios = $("input[name='usertype']");

		for (var i = 0; i < radios.length; i++) {
			if (value == radios[i].value) {
				radios[i].checked = true;
			}
		}
	}
	function usertypee(val) {	
		if (val == 'manager') {
			return '管理员';
		} else if (val == 'student') {
			return '学生';
		} else if (val == 'teacher') {
			return '教师';
		}
	} 
    function page(){  
       var $table = $('.table-scrollable');  
       var currentPage = 0;//当前页默认值为0  
       var pageSize = 3;//每一页显示的数目  
       $table.bind('paging',function(){  
           $table.find('tbody tr').hide().slice(currentPage*pageSize,(currentPage+1)*pageSize).show();  
       });       
       var sumRows = $table.find('tbody tr').length;  
       var sumPages = Math.ceil(sumRows/pageSize);//总页数  
         
       var $pager = $('<div class="page"></div>');  //新建div，放入a标签,显示底部分页码  
       for(var pageIndex = 0 ; pageIndex<sumPages ; pageIndex++){  
           $('<a href="#" id="pageStyle" onclick="changCss(this)"><span>'+(pageIndex+1)+'</span></a>').bind("click",{"newPage":pageIndex},function(event){  
               currentPage = event.data["newPage"];  
               $table.trigger("paging");  
                 //触发分页函数  
               }).appendTo($pager);  
               $pager.append(" ");  
           }     
           $pager.insertAfter($table);  
           $table.trigger("paging");  
             
           //默认第一页的a标签效果  
           var $pagess = $('#pageStyle');  
           $pagess[0].style.backgroundColor="#006B00";  
           $pagess[0].style.color="#ffffff";  
  }  
    
  //a链接点击变色，再点其他回复原色  
    function changCss(obj){  
      var arr = document.getElementsByTagName("a");  
      for(var i=0;i<arr.length;i++){     
       if(obj==arr[i]){       //当前页样式  
        obj.style.backgroundColor="#006B00";  
        obj.style.color="#ffffff";  
      }  
       else  
       {  
         arr[i].style.color="";  
         arr[i].style.backgroundColor="";  
       }  
      }  
   }      
	jQuery(document).ready(function() {
		init();
		//page();
		handleAddValidation();
	});


