function showuserlist() {
	
	$('#userlistTable').DataTable( {
		ajax: {
	        url: 'FindServlet',
	        dataSrc: ''
	    },
	    columns: [
	    	{ data: 'id' },
	        { data: 'username' },
	        { data: 'usertype' },
	        { data: 'usertrue' },
	        { data: 'email' },
	        { data: 'tel' },
	        { data:'company' }
	    ]
	} );	
}
function init(){
	$.getJSON("ShowAllServlet?table=c",function(data){
		   $("#editcbody").html("");
		   $.each(data,function(i,item){
	        var tr = "<tr class=\"\" >";
			tr += "<td>" + item.cno + "</td>";					
			tr += "<td>" + item.cname + "</td>";
			tr += "<td>" + item.cpno + "</td>";
			tr += "<td>" + item.credit + "</td>";
			tr += "<td>" + item.tname + "</td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs purple' onclick='OpenEditForm("+item.cno+")'><i class='fa fa-edit'></i> 修改 </a></td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs black' onclick='DeleteUser("+item.cno+")' ><i class='fa fa-trash-o'></i> 删除 </a></td></td>";
		tr += "</tr>";
		//alert(item.snumber);
		$("#editcbody").append(tr);	
	   })
   })
}
	var isAddOrEdit = "add";
	function showusers() {
		alert("123");
		$("#editcbody").html("");
		$.getJSON("FindServlet?search="+$("#search").val()+"&table=c", function(data) {
			$.each(data, function(i) {
				// alert(this.id);
				var tr = "<tr class=\"\" >";		
				tr += "<td>" + this.cno + "</td>";
				tr += "<td>" + this.cname + "</td>";
				tr += "<td>" + this.cpno + "</td>";
				tr += "<td>" + this.credit + "</td>";
				tr += "<td>" + this.tname + "</td>";
				tr += "<td><a href='javascript:;' class='btn default btn-xs purple'  onclick='OpenEditForm(" + this.Snumber + ")'>";
				tr += "<i class='fa fa-edit'></i> 编辑 </a></td>";
				tr += "<td><a href='javascript:;' class='btn default btn-xs black'  onclick='DeleteUser(" + this.Snumber + ")'  >";
				tr += "<i class='fa fa-trash-o'></i>删除 </a></td>";
				tr += "</tr>";
				$("#editcbody").append(tr);
			});
		});
	}
	var addform = $('#Addform');
	var error2 = $('.alert-danger', addform);
	var success2 = $('.alert-success', addform);
	// validation using icons
	var handleAddValidation = function() {
	addform.validate({
			errorElement : 'span', //default input error message container
			errorClass : 'help-block help-block-error', // default input error message class
			focusInvalid : false, // do not focus the last invalid input
			ignore : "", // validate all fields including form hidden input
			rules : {
				Cno : {
					required : true,
					minlength : 1,
					maxlength : 3
				},
				Cname : {
					required : true,
					minlength : 2,
					maxlength : 15
				},
				Cpno : {
					required : false,
					minlength : 1,
					maxlength : 3
				},
				Credit : {
					required : true,
					minlength : 1,
					maxlength : 1
				},
				Tname : {
					required : true,
					minlength : 2,
					maxlength : 4
				},
				Tno : {
					required : false,
					minlength : 10,
					maxlength : 15
				}
			},

			invalidHandler : function(event, validator) { //display error alert on form submit              
				success2.hide();
				error2.show();
				Metronic.scrollTo(error2, -200);
			},

			highlight : function(element) { // hightlight error inputs
				$(element).closest('.form-group').removeClass("has-success").addClass('has-error'); // set error class to the control group   
			},

			unhighlight : function(element) { // revert the change done by hightlight
				$(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
			},

			success : function(label) {
				label.closest('.form-group').removeClass('has-error'); // set success class to the control group
			},

			submitHandler : function(form) {
				success2.show();
				error2.hide();
				if (isAddOrEdit == 'add') {
					add();
				} else {
					edit();
				}

			}
		});

	}
	function OpenAddForm() {
		isAddOrEdit = 'add';//新增对话框标识  
		$('#Addform')[0].reset();
		success2.hide();
		error2.hide();
		$('.form-group').removeClass('has-error');
		$('.help-block-error').remove();
		$("#addmodaleditc").modal("show");
	}
	function add() {
		var postData = $("#Addform").serialize()+"&table=c";
		//alert(postData);
		$.post("RegServlet",postData,function(data) {
			if (data == "1") {
				$('#addmodaleditc').modal('hide');
				bootbox.alert("添加成功");
				init();
			} else
				//alert("注册失败");
				bootbox.alert("添加失败!");
		}, "json");
	}
	function edit() {
		var postData = $("#Addform").serialize()+"&table=c";
		$.post("UpdateServlet", postData, function(data) {
			//alert(data.equals("c")==true);
			if (data == "1") {
				$('#addmodaleditc').modal('hide');	
				bootbox.alert("修改成功");
				init();
			} else
				bootbox.alert("课程号不能改变，修改失败!");
		}, "json");
	}

	function OpenEditForm(cno) {
       /* var tr = e.parentNode.parentNode;
        var Snumber=tr.cells[1].innerText; 
		isAddOrEdit = 'edit';//新增对话框标识  
		$('#Snumber').val(Snumber);*/
		isAddOrEdit = 'edit';
		$('#Addform')[0].reset();
		success2.hide();
		error2.hide();
		$('.form-group').removeClass('has-error');
		$('.help-block-error').remove();
		$('#addmodaleditc').modal('show');

		$.getJSON("FindServlet?Cno=" + cno+"&table=c", function(data) {
			//alert(data)
			$.each(data, function(i) {
			
				if (i == 0) {
					$('#Cno').val(this.cno); 
					$('#Cname').val(this.cname);
					$('#Cpno').val(this.cpno);
					$('#Credit').val(this.credit);
					$('#Tname').val(this.tname);
				}
			});
		});
	}
	function DeleteUser(cno) {
		/*var tr = e.parentNode.parentNode;
        var Snumber=tr.cells[1].innerText;*/
		bootbox.confirm({
			message : "您真的要删除此用户?",
			title : "询问？",
			callback : function(result) {
				if (result == true) {
					$.get("DeleteServlet?cno=" + cno+"&table=c", function(data) {
						if (data > 0) {
							bootbox.alert("删除成功!");
							//createTable();
							init();
						} else
							//alert("删除失败");
							bootbox.alert("删除失败!");
					});
				}
			},
			buttons : {
				confirm : {
					label : '是',
					className : 'btn-success'
				},
				cancel : {
					label : '否',
					className : 'btn-danger'
				}
			},
		});
	}  
	jQuery(document).ready(function() {
		init();
		//page();
		handleAddValidation();
	});


