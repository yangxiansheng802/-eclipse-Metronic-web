function initp(){
    $.ajax({
   url:'ShowAllServlet',
   type:'post',
   data:{
       table:'loginsheet'
    },
   dataType:'json',
   success:function(data){
	   $("#pwbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + (i+1) + "</td>";	
		tr += "<td>" + item.snumber + "</td>";					
		tr += "<td>" + item.password + "</td>";
		tr += "<td><a href='javacript:;' class='btn default btn-xs black' onclick='repw(this)' ><i class='fa fa-trash-o'></i> 重置 </a></td></td>";
		tr += "</tr>";
		//alert(item.password);
		$("#pwbody").append(tr);
	
	   })
    }
   })
}
function repw(e) {
	var tr = e.parentNode.parentNode;
    var Snumber=tr.cells[1].innerText;
	bootbox.confirm({
		message : "确认重置此密码？",
		title : "询问？",
		callback : function(result) {
			if (result == true) {
				$.get("reServlet?Snumber=" + Snumber, function(data) {
					if (data > 0) {
						bootbox.alert("重置成功!");
						//createTable();
						initp();
						//window.location.reload(password.jsp);
					} else
						//alert("删除失败");
						bootbox.alert("重置失败!");
				});
			}
		},
		buttons : {
			confirm : {
				label : '是',
				className : 'btn-success'
			},
			cancel : {
				label : '否',
				className : 'btn-danger'
			}
		},
	});
}
	jQuery(document).ready(function() {
		initp();
	});


