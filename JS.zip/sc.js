function init(){
	var snumber=$.session.get('snumber');
    $.getJSON("ShowAllServlet?table=sc&sno="+snumber,function(data){
	   $("#scbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + item.sno + "</td>";					
		tr += "<td>" + item.cno + "</td>";
		tr += "<td>" + item.grade + "</td>";
		tr += "</tr>";
		$("#scbody").append(tr);	
	   });
   });
    $.getJSON("avg?table=sc&sno="+snumber,function(data){
 	   $("#avgbody").html("");

         var tr = "<tr class=\"\" >";
 		tr += "<td>" + data.sum + "</td>";
 		tr += "<td>" + data.avg + "</td>";
 		tr += "<td>" + data.min + "</td>";
 		tr += "<td>" + data.max + "</td>";
 		tr += "</tr>";
 		$("#avgbody").append(tr);	
 	   
    });
}
	function searchsc() {
		$("#scbody").html("");
		var sno=$.session.get('snumber');
		$.getJSON("FindServlet?search="+$("#search").val()+"&sno="+sno+"&table=sc", function(data) {
			$.each(data, function(i) {
				// alert(this.id);
				 var tr = "<tr class=\"\" >";
					tr += "<td>" + this.sno + "</td>";					
					tr += "<td>" + this.cno + "</td>";
					tr += "<td>" + this.grade + "</td>";
					tr += "</tr>";
					$("#scbody").append(tr);
			});
		});
	}
	jQuery(document).ready(function() {
		init();
	});


