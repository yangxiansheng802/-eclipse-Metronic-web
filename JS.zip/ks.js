function init(){
	var snumber=$.session.get('snumber');
    $.getJSON("Shows?table=sc&sno="+snumber,function(data){
	   $("#ksbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + item.sno + "</td>";					
		tr += "<td>" + item.cno + "</td>";
		tr += "<td>" + item.grade + "</td>";
		tr += "</tr>";
		$("#ksbody").append(tr);	
	   });
   });
}
	jQuery(document).ready(function() {
		init();
	});


