var handleLogin = function() {
	
 
	
	if ($.cookie('Snumber')!=null) {
		$('#Snumber').val($.cookie('Snumber')); 
		$('#password').val($.cookie('password'));
	}
	

	$('.login-form').validate({
		errorElement : 'span', // default input error message container
		errorClass : 'help-block', // default input error message class
		focusInvalid : false, // do not focus the last invalid input
		rules : {
			Snumber : {
				required : true,
				minlength : 4,
				maxlength : 16
			},
			password : {
				required : true
			},
			remember : {
				required : false
			}
		},

		messages : {
			Snumber : {
				required : "Snumber is required.",
				minlength : "最小长度为4",
				maxlength : "最大长度为16"
			},
			password : {
				required : "请输入密码"
			}
		},

		invalidHandler : function(event, validator) { // display error alert
														// on form submit
			$('.alert-danger', $('.login-form')).show();
		},

		highlight : function(element) { // hightlight error inputs
			$(element).closest('.form-group').addClass('has-error'); 
		},

		success : function(label) {
			label.closest('.form-group').removeClass('has-error');
			label.remove();
		},

		errorPlacement : function(error, element) {
			error.insertAfter(element.closest('.input-icon'));
		},

		submitHandler : function(form) {
			// form.submit(); // form validation success, call ajax form submit
			loginformsubmit();
		}
	});

	$('.login-form input').keypress(function(e) {
		if (e.which == 13) {
			if ($('.login-form').validate().form()) {
				$('.login-form').submit(); // form validation success, call
											// ajax form submit
			}
			return false;
		}
	});
}
function loginformsubmit() {
	if ($('#remember').is(':checked')) {
		$.cookie('rememberme', 'true', {
			expires : 7
		});
		$.cookie('Snumber', $('#Snumber').val(), {
			expires : 7
		});
		$.cookie('password', $('#password').val(), {
		 expires : 7
		 });
	} else {
		$.cookie('rememberme', null);
	}
	var postData = $(".login-form").serialize();
	var usertype=$('input[name="radio2"]:checked').val();
	alert(postData);
	$.get("LoginServlet?"+postData, function(data) {
		alert(data);
		if (data > 0) {
			$.session.set('usertype', usertype);
			$.session.set('snumber', $('#Snumber').val());
			//alert($.session.get('usertype'));
			location.href = "Index.jsp";
		} else {
			// alert("登录失败");
			location.href = "LoginResult.jsp";
		}
	});

}
