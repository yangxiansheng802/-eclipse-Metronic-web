function init(){
    $.getJSON("ShowAllServlet?table=c",function(data){
	   $("#cbody").html("");
	   $.each(data,function(i,item){
        var tr = "<tr class=\"\" >";
		tr += "<td>" + item.cno + "</td>";					
		tr += "<td>" + item.cname + "</td>";
		tr += "<td>" + item.cpno + "</td>";
		tr += "<td>" + item.credit + "</td>";
		tr += "<td>" + item.tname + "</td>";
		tr += "<td><a href='javacript:;' class='btn green' onclick='choosec("+this.cno+")'><i class='fa fa-edit'></i> 选定 </a></td>";
		tr += "</tr>";
		$("#cbody").append(tr);	
	   });
   });
}
	function searchc() {
		$("#cbody").html("");
		$.getJSON("FindServlet?search="+$("#search").val()+"&table=c", function(data) {
			$.each(data, function(i) {
				// alert(this.id);
				var tr = "<tr class=\"\" >";		
				tr += "<td>" + this.cno + "</td>";
				tr += "<td>" + this.cname + "</td>";
				tr += "<td>" + this.cpno + "</td>";
				tr += "<td>" + this.credit + "</td>";
				tr += "<td>" + this.tname + "</td>";
				tr += "<td><a href='javascript:;' class='btn green'  onclick='choosec("+this.cno+")'>";
				tr += "<i class='fa fa-edit'></i> 选定 </a></td>";
				tr += "</tr>";
				$("#cbody").append(tr);
			});
		});
	}
	function choosec(Cno) {
		//var tr = e.parentNode.parentNode;
        //var Cno=tr.cells[0].innerHTML;
        alert(Cno);
        var snumber=$.session.get('snumber');
		$.get("RegServlet?cno="+Cno+"&snumber="+snumber+"&table=sc", function(data) {
			if (data == "1") {
				bootbox.alert("选定成功");
				init();
			} else
				bootbox.alert("选定失败!您已进行过选定");
		}, "json");
	}
	jQuery(document).ready(function() {
		init();
	});


