package cn.xaut.bean;

public class Cinfo {
	private String Cno;
	private String Cname;
	private String Cpno;
	private String Credit;
	private String Tname;
	public String getCno() {
		return Cno;
	}
	public void setCno(String cno) {
		Cno = cno;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCpno() {
		return Cpno;
	}
	public void setCpno(String cpno) {
		Cpno = cpno;
	}
	public String getCredit() {
		return Credit;
	}
	public void setCredit(String credit) {
		Credit = credit;
	}
	public String getTname() {
		return Tname;
	}
	public void setTname(String tname) {
		Tname = tname;
	}

}
