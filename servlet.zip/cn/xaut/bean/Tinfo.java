package cn.xaut.bean;

public class Tinfo {
private String Tno;
private String Tcno;
public String getTno() {
	return Tno;
}
public void setTno(String tno) {
	Tno = tno;
}
public String getTcno() {
	return Tcno;
}
public void setTcno(String tcno) {
	Tcno = tcno;
}
}
