package cn.xaut.bean;

import java.io.Serializable;

public class UserInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String getusername() {
		return username;
	}

	public void setusername(String username) {
		this.username = username;
	}

	public String getiphone() {
		return iphone;
	}

	public void setiphone(String iphone) {
		this.iphone = iphone;
	}

	public String getemailbox() {
		return mailbox;
	}

	public void setmailbox(String mailbox) {
		this.mailbox = mailbox;
	}

	public String getcompany() {
		return company;
	}

	public void setcompany(String company) {
		this.company = company;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private String Snumber;

	private String username;

	private String iphone;

	private String mailbox;

	private String company;
	
	private String password;
	
	private String usertype;

	public String getusertype() {
		return usertype;
	}

	public void setusertype(String usertype) {
		this.usertype = usertype;
	}
	public String getSnumber() {
		return Snumber;
		
	}

	public void setSnumber( String Snumber) {
		this.Snumber = Snumber;
		
	}

}
