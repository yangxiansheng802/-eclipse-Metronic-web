/*
 * package cn.xaut.servlet;
 * 
 * import java.io.IOException; import java.sql.ResultSet; import
 * java.sql.SQLException; import java.util.ArrayList; import java.util.List;
 * 
 * import javax.servlet.ServletException; import
 * javax.servlet.annotation.WebServlet; import javax.servlet.http.HttpServlet;
 * import javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse;
 * 
 * import cn.xaut.bean.Cinfo; import cn.xaut.bean.Scinfo; import
 * cn.xaut.bean.Tinfo; import cn.xaut.bean.UserInfo; import cn.xaut.db.ConnDB;
 * import net.sf.json.JSONArray;
 * 
 *//**
	 * Servlet implementation class shows
	 */
/*
 * @WebServlet("/shows") public class shows extends HttpServlet { private static
 * final long serialVersionUID = 1L;
 * 
 *//**
	 * @see HttpServlet#HttpServlet()
	 */
/*
 * public shows() { super(); // TODO Auto-generated constructor stub }
 * 
 *//**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
/*
 * protected void doGet(HttpServletRequest request, HttpServletResponse
 * response) throws ServletException, IOException {
 * request.setCharacterEncoding("utf-8"); String table =
 * request.getParameter("table"); String Tno = request.getParameter("sno");
 * String sql = "select Tcno from tc where Tno="+Tno; System.out.println(sql);
 * List<Scinfo> list = new ArrayList<Scinfo>();
 * 
 * List<UserInfo> list = new ArrayList<UserInfo>(); List<Cinfo> list1 = new
 * ArrayList<Cinfo>(); List<Scinfo> list2 = new ArrayList<Scinfo>(); List<Tinfo>
 * list3 = new ArrayList<Tinfo>();
 * 
 * try { ResultSet rs = ConnDB.query(sql); while (rs.next()) {
 * System.out.println(rs.next()); String sql1 =
 * "select * from sc where Cno="+rs.next(); ResultSet rs1 = ConnDB.query(sql1);
 * Scinfo scinfo = new Scinfo(); scinfo.setCno(rs.getString("Cno"));
 * scinfo.setSno(rs.getString("Sno")); scinfo.setGrade(rs.getString("Grade"));
 * list.add(scinfo); } request.setAttribute("list", list); rs.close(); //
 * 关闭ResultSet rs1.close(); ConnDB.close(); // 关闭 } catch (SQLException e) {
 * e.printStackTrace(); } response.setCharacterEncoding("utf-8"); JSONArray
 * jsonArray = JSONArray.fromObject(list); //System.out.println(jsonArray); }
 * 
 *//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 *//*
		 * protected void doPost(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException { // TODO Auto-generated
		 * method stub doGet(request, response); }
		 * 
		 * }
		 */