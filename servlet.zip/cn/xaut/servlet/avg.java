package cn.xaut.servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.sun.crypto.provider.RSACipher;

import cn.xaut.bean.Avg;
import cn.xaut.db.ConnDB;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class avg
 */
@WebServlet("/avg")
public class avg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public avg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String table = request.getParameter("table");
		 if (table.equals("sc")==true) {
		Avg avg=new Avg();
			try {
			String sno = request.getParameter("sno");
			String sql = "SELECT sum(grade) from (SELECT Sno,Grade from sc WHERE grade>0) as c where Sno="+sno;
			String sql1 = "SELECT avg(grade) from (SELECT Sno,Grade from sc WHERE grade>0) as c where Sno="+sno;
			String sql2 = "SELECT min(grade) from (SELECT Sno,Grade from sc WHERE grade>0) as c where Sno="+sno;
			String sql3 = "SELECT max(grade) from (SELECT Sno,Grade from sc WHERE grade>0) as c where Sno="+sno;
			ResultSet rs = ConnDB.query(sql);
			while (rs.next()) {
				System.out.println(rs.getString(1));
				avg.setSum(rs.getString(1));
				System.out.print(sql);
			}
			ResultSet rs1 = ConnDB.query(sql1);
			while (rs1.next()) {
				System.out.println(rs1.getString(1));
				avg.setAvg(rs1.getString(1));
				System.out.print(sql1);
			}
			ResultSet rs2 = ConnDB.query(sql2);
			while (rs2.next()) {
				System.out.println(rs2.getString(1));	
				avg.setMin(rs2.getString(1));
				System.out.print(sql2);
			}
			ResultSet rs3 = ConnDB.query(sql3);
			while (rs3.next()) {
				System.out.println(rs3.getString(1));
				avg.setMax(rs3.getString(1));
				System.out.print(sql3);
			}
			ConnDB.close();
			rs.close();
			rs1.close();
			rs2.close();
			rs3.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			JSONObject json = JSONObject.fromObject(avg); 
			response.getWriter().print(json);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
