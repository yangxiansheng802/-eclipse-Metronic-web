package cn.xaut.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xaut.bean.Cinfo;
import cn.xaut.bean.Scinfo;
import cn.xaut.bean.UserInfo;
import cn.xaut.db.ConnDB;
import net.sf.json.JSONArray;

/**
 * Servlet implementation class FindServlet
 */
@WebServlet("/FindServlet")
public class FindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FindServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		List<UserInfo> list = new ArrayList<UserInfo>();
		List<Cinfo> list1 = new ArrayList<Cinfo>();
		List<Scinfo> list2 = new ArrayList<Scinfo>();
		String table = request.getParameter("table");
		System.out.println(table);
		try {
			String searchtext = request.getParameter("search");
			System.out.println(searchtext);
			String sql = "select * from " + table + " where ";
			if (table.equals("loginsheet") == true) {
				String s = request.getParameter("Snumber");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Snumber='" + searchtext + "'";
				} else if (s != null && !"".equals(s)) {

					sql = sql + " Snumber='" + s + "'";
				}
				System.out.println(sql);
			}else if (table.equals("c")==true) {
				String s = request.getParameter("Cno");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Cno='" + searchtext + "'";
				} else if (s != null && !"".equals(s)) {

					sql = sql + " Cno='" + s + "'";
				}
				System.out.println(sql);
			}else if (table.equals("sc")==true) {
				String s = request.getParameter("sno");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Sno='" + s + "' and Cno='"+searchtext+"'";
				} 
				System.out.println(sql);
			}
			ResultSet rs = ConnDB.query(sql);
			System.out.println(rs);
			// 判断光标向后移动，并判断是否有效
			while (rs.next()) {
				if (table.equals("loginsheet")==true) {
				UserInfo userinfo = new UserInfo();
				userinfo.setSnumber(rs.getString("Snumber"));
				userinfo.setusername(rs.getString("username"));
				userinfo.setPassword(rs.getString("password"));
				userinfo.setusertype(rs.getString("usertype"));
				userinfo.setiphone(rs.getString("iphone"));
				userinfo.setcompany(rs.getString("company"));
				userinfo.setmailbox(rs.getString("mailbox"));
				list.add(userinfo);
				}else if (table.equals("c")==true) {
					Cinfo cinfo = new Cinfo();
					cinfo.setCno(rs.getString("Cno"));
					cinfo.setCname(rs.getString("Cname"));
					cinfo.setCpno(rs.getString("Cpno"));
					cinfo.setCredit(rs.getString("Credit"));
					cinfo.setTname(rs.getString("Tname"));
					list1.add(cinfo);
				}else if (table.equals("sc")==true) {
					Scinfo scinfo = new Scinfo();
					scinfo.setCno(rs.getString("Cno"));
					scinfo.setSno(rs.getString("Sno"));
					scinfo.setGrade(rs.getString("Grade"));
					list2.add(scinfo);
				}
			}

			if (table.equals("loginsheet")==true)
				request.setAttribute("list", list);
			else if (table.equals("c")==true) {
				request.setAttribute("list", list1);
			}else if (table.equals("sc")==true) {
				request.setAttribute("list", list2);
			}
			rs.close(); // 关闭ResultSet
			ConnDB.close(); // 关闭
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.setCharacterEncoding("utf-8");
		if (table.equals("loginsheet")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list);
			System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		} else if (table.equals("c")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list1);
			System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}else if (table.equals("sc")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list2);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		List<UserInfo> list = new ArrayList<UserInfo>();
		List<Cinfo> list1 = new ArrayList<Cinfo>();
		List<Scinfo> list2 = new ArrayList<Scinfo>();
		String table = request.getParameter("table");
		System.out.println(table);
		try {
			String searchtext = request.getParameter("search");
			System.out.println(searchtext);
			String sql = "select * from " + table + " where ";
			if (table.equals("loginsheet") == true) {
				String s = request.getParameter("Snumber");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Snumber='" + searchtext + "'";
				} else if (s != null && !"".equals(s)) {

					sql = sql + " Snumber='" + s + "'";
				}
				System.out.println(sql);
			}else if (table.equals("c")==true) {
				String s = request.getParameter("Cno");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Cno='" + searchtext + "'";
				} else if (s != null && !"".equals(s)) {

					sql = sql + " Cno='" + s + "'";
				}
				System.out.println(sql);
			}else if (table.equals("sc")==true) {
				String s = request.getParameter("sno");
				if (searchtext != null && !"".equals(searchtext)) {

					sql = sql + " Sno='" + s + "' and Cno='"+searchtext+"'";
				} 
				System.out.println(sql);
			}
			ResultSet rs = ConnDB.query(sql);
			System.out.println(rs);
			// 判断光标向后移动，并判断是否有效
			while (rs.next()) {
				if (table.equals("loginsheet")==true) {
				UserInfo userinfo = new UserInfo();
				userinfo.setSnumber(rs.getString("Snumber"));
				userinfo.setusername(rs.getString("username"));
				userinfo.setPassword(rs.getString("password"));
				userinfo.setusertype(rs.getString("usertype"));
				userinfo.setiphone(rs.getString("iphone"));
				userinfo.setcompany(rs.getString("company"));
				userinfo.setmailbox(rs.getString("mailbox"));
				list.add(userinfo);
				}else if (table.equals("c")==true) {
					Cinfo cinfo = new Cinfo();
					cinfo.setCno(rs.getString("Cno"));
					cinfo.setCname(rs.getString("Cname"));
					cinfo.setCpno(rs.getString("Cpno"));
					cinfo.setCredit(rs.getString("Credit"));
					cinfo.setTname(rs.getString("Tname"));
					list1.add(cinfo);
				}else if (table.equals("sc")==true) {
					Scinfo scinfo = new Scinfo();
					scinfo.setCno(rs.getString("Cno"));
					scinfo.setSno(rs.getString("Sno"));
					scinfo.setGrade(rs.getString("Grade"));
					list2.add(scinfo);
				}
			}

			if (table.equals("loginsheet")==true)
				request.setAttribute("list", list);
			else if (table.equals("c")==true) {
				request.setAttribute("list", list1);
			}else if (table.equals("sc")==true) {
				request.setAttribute("list", list2);
			}
			rs.close(); // 关闭ResultSet
			ConnDB.close(); // 关闭
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.setCharacterEncoding("utf-8");
		if (table.equals("loginsheet")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list);
			System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		} else if (table.equals("c")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list1);
			System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}else if (table.equals("sc")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list2);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}
	}
}
