package cn.xaut.servlet;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xaut.db.ConnDB;

/**
 * Servlet implementation class RegServlet
 */
@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String table = request.getParameter("table");
		System.out.print(table);
		if (table.equals("loginsheet")==true) {
		String isEdit = request.getParameter("isAddOrEdit");
		if (isEdit != null && !"".equals(isEdit) && "true".equals(isEdit)) {
			request.getRequestDispatcher("UpdateServlet").forward(request, response);
		} else {
			try {
			String sql = "insert  into loginsheet(Snumber,password,username,usertype,iphone,mailbox,company) values('"
					+ request.getParameter("Snumber") + "','" + request.getParameter("password") + "','"
					+ request.getParameter("username") + "','" + request.getParameter("usertype") + "','"
					+ request.getParameter("iphone") + "','" + request.getParameter("mailbox") + "','"
					+ request.getParameter("company") + "')";
			System.out.print(sql);
			int rs = ConnDB.update(sql);
			String m=""+rs;
			ConnDB.close();
			System.out.println(m);
			response.getWriter().write(m);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}else if (table.equals("sc")==true) {
			String Cno = request.getParameter("cno");
			String Sno = request.getParameter("snumber");
			String Grade=null;
			String m="";
				try {
				String sql1 = "select *  from sc where Sno='"+Sno+"' and Cno='"+Cno+"';";
				System.out.print(sql1);
				ResultSet rs1 = ConnDB.query(sql1);
				if(!rs1.next()) {					
				String sql = "insert  into sc(Sno,Cno,Grade) values('"
						+ Sno + "','" +Cno + "','"
						+ Grade +"')";
				System.out.println(sql);
				int rs = ConnDB.update(sql);
			    m=""+rs;
				ConnDB.close();
				System.out.println(m);
				response.getWriter().write(m);}
				} catch (Exception e) {
					e.printStackTrace();
				}
			
		}else if (table.equals("c")==true) {
			String m="";
			String Tno = request.getParameter("Tno");
			String Tcno =request.getParameter("Cno");
			String Cname =request.getParameter("Cname");
			System.out.println(Cname);
				try {
					String sql = "insert  into c(Cno,Cname,Cpno,Credit,Tname) values('"
							+ Tcno + "','" + Cname + "','"
							+ request.getParameter("Cpno") + "','" + request.getParameter("Credit") + "','"
							+ request.getParameter("Tname") + "')";				
				System.out.println(sql);
				int rs = ConnDB.update(sql);
			    m=""+rs;
			    String sql1 = "insert  into tc(Tno,Tcno) values('"+ Tno + "','" +Tcno + "')";
			    System.out.println(sql1);
				ConnDB.update(sql1);
				ConnDB.close();
				System.out.println(m);
				response.getWriter().write(m);
				} catch (Exception e) {
					e.printStackTrace();
				}
			
		}		
	}
}
