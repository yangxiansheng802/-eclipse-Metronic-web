package cn.xaut.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import org.apache.jasper.tagplugins.jstl.core.Out;

import cn.xaut.db.ConnDB;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		System.out.println("45313");
		response.setCharacterEncoding("UTF-8");
		String Snumber = request.getParameter("Snumber");
		String password = request.getParameter("password");
		String usertype = request.getParameter("radio2");
		if (!"".equals(Snumber) && !"".equals(password)&& !"".equals(usertype)) {
			try {
				String sql = "select * from loginsheet where Snumber='" + Snumber + "' and password='"
						+ password + "' and usertype='"+usertype+"'";
				System.out.println(sql);
				ResultSet rs = ConnDB.query(sql);
				System.out.println(sql);
				rs.last(); 
				int rowCount = rs.getRow(); 
				rs.close(); 
				ConnDB.close();
				if (rowCount > 0) {
					HttpSession session = request.getSession();
					session.setAttribute("user", Snumber); } 
				response.getWriter().print(rowCount);
                System.out.println(rowCount);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
