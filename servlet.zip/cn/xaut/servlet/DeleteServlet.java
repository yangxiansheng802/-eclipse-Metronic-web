package cn.xaut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xaut.db.ConnDB;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	  
		request.setCharacterEncoding("utf-8");
		String table = request.getParameter("table");
		if (table.equals("loginsheet")==true) { 
		String Snumber = request.getParameter("Snumber");
		String sql = "delete from loginsheet where Snumber = " + Snumber;
		System.out.print(sql);
		int rows = ConnDB.update(sql);
		response.getWriter().print(rows);
		ConnDB.close();
	}else if(table.equals("c")==true) {
		String cno = request.getParameter("cno");
		String sql = "delete from c where Cno = " + cno;
		String sql1 = "delete from tc where Tcno = " + cno;
		System.out.print(sql);
		System.out.print(sql1);
		int rows = ConnDB.update(sql);
		int rows1 = ConnDB.update(sql1);
		response.getWriter().print(rows);
		ConnDB.close();
	}
	}
}
