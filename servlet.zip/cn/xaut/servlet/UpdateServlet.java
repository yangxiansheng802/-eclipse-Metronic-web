package cn.xaut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import cn.xaut.db.ConnDB;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int rows=0;
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String table = request.getParameter("table");
		if (table.equals("loginsheet")==true) {
		String Snumber = request.getParameter("Snumber");
		try {
		String sql = "update loginsheet " + "set username='" + request.getParameter("username")
				+ "',password='" + request.getParameter("password") + "',usertype='"
				+ request.getParameter("usertype")+ "',company='" + request.getParameter("company") + "',iphone='" + request.getParameter("iphone")
				+ "',mailbox='" + request.getParameter("mailbox") + "' where Snumber = " + Snumber;
		System.out.print(sql);
		rows = ConnDB.update(sql);
		ConnDB.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.getWriter().write(new Gson().toJson(rows));
		}else if (table.equals("c")==true) {
			try {
			String Cno = request.getParameter("Cno");
			String Tno = request.getParameter("Tno");
			String sql = "update c " + "set Cname='" + request.getParameter("Cname")
					+ "',Cpno='" + request.getParameter("Cpno") + "',Credit='"
					+ request.getParameter("Credit")+ "',Tname='" + request.getParameter("Tname") +  
					"' where Cno = " + Cno;
			if("".equals(Tno)==true||Tno==null) {}
			else {
				String sql1 = "update tc set Tno='"+ Tno+"' where Tcno=" +Cno ;
			    System.out.println(sql1);
				ConnDB.update(sql1);
				ConnDB.close();
			}
			System.out.print(sql);
			rows = ConnDB.update(sql);
			System.out.print(rows);
			ConnDB.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.print(rows);
			response.getWriter().write(new Gson().toJson(rows));
		}
	}

}
