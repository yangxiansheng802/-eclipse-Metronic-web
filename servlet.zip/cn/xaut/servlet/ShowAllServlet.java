package cn.xaut.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xaut.bean.Cinfo;
import cn.xaut.bean.Scinfo;
import cn.xaut.bean.Tinfo;
import cn.xaut.bean.UserInfo;
import cn.xaut.db.ConnDB;
import net.sf.json.JSONArray;

/**
 * Servlet implementation class ShowAllServlet
 */
@WebServlet("/ShowAllServlet")
public class ShowAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowAllServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String table = request.getParameter("table");
		String sno = request.getParameter("sno");
		String tno = request.getParameter("tno");
		String sql = "select * from " + table;
		System.out.println(sql);
		List<UserInfo> list = new ArrayList<UserInfo>();
		List<Cinfo> list1 = new ArrayList<Cinfo>();
		List<Scinfo> list2 = new ArrayList<Scinfo>();
		List<Tinfo> list3 = new ArrayList<Tinfo>();
		try {
			ResultSet rs = ConnDB.query(sql);
			while (rs.next()) {
				//System.out.println("1");
				if (table.equals("loginsheet")==true) {
					UserInfo userinfo = new UserInfo();
					userinfo.setSnumber(rs.getString("Snumber"));
					userinfo.setPassword(rs.getString("password"));
					userinfo.setusername(rs.getString("username"));
					userinfo.setusertype(rs.getString("usertype"));
					userinfo.setiphone(rs.getString("iphone"));
					userinfo.setmailbox(rs.getString("mailbox"));
					userinfo.setcompany(rs.getString("company"));
					list.add(userinfo);
				} else if (table.equals("c")==true) {
					Cinfo cinfo = new Cinfo();
					cinfo.setCno(rs.getString("Cno"));
					cinfo.setCname(rs.getString("Cname"));
					cinfo.setCpno(rs.getString("Cpno"));
					cinfo.setCredit(rs.getString("Credit"));
					cinfo.setTname(rs.getString("Tname"));
					list1.add(cinfo);
				}else if (table.equals("sc")==true) {
					if(sno.equals(rs.getString("Sno"))==true) {
					Scinfo scinfo = new Scinfo();
					scinfo.setCno(rs.getString("Cno"));
					scinfo.setSno(rs.getString("Sno"));
					scinfo.setGrade(rs.getString("Grade"));
					list2.add(scinfo);
					}
				}else if (table.equals("tc")==true) {
					if(tno.equals(rs.getString("Tno"))==true) {
					Tinfo tinfo = new Tinfo();
					tinfo.setTno(rs.getString("Tno"));
					tinfo.setTcno(rs.getString("Tcno"));
					list3.add(tinfo);
					}
				}
			}
			if (table.equals("loginsheet")==true)
				request.setAttribute("list", list);
			else if (table.equals("c")==true) {
				request.setAttribute("list", list1);
			}else if (table.equals("sc")==true) {
				request.setAttribute("list", list2);
			}else if (table.equals("tc")==true) {
				request.setAttribute("list", list3);
			}
			rs.close(); // 关闭ResultSet
			ConnDB.close(); // 关闭
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.setCharacterEncoding("utf-8");
		if (table.equals("loginsheet")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		} else if (table.equals("c")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list1);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}else if (table.equals("sc")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list2);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}else if (table.equals("tc")==true) {
			JSONArray jsonArray = JSONArray.fromObject(list3);
			//System.out.println(jsonArray);
			response.getWriter().print(jsonArray);
		}
	}

}
