package cn.xaut.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnDB {
	// 驱动名称
	private static final String driverName = "com.mysql.jdbc.Driver";
	// 数据库的地址(通过端口和SID找到对应的数据库)
	private static final String URL = "jdbc:mysql://localhost:3333/user? useUnicode=true&characterEncoding=UTF-8";
	// 数据库登录用户名
	private static final String userName = "root";	// 数据库登录密码
	private static final String pwd = "cf0526....";	
	private static Connection connection = null;	
	private static Statement stat = null;	
	private static PreparedStatement ps = null;	
	private static ResultSet rs1 = null;	
	private static int rows = 0;
	
	public static Connection getConnection() {
		try {
			// 加载mysql驱动
			Class.forName(driverName);
			// 通过驱动获取数据库的连接
			connection = DriverManager.getConnection(URL, userName, pwd);
			System.out.println("连接成功");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
	public static ResultSet query(String sql) {
		try {
			// 通过刚才的getConnection方法获得一个连接的对象。
			connection = getConnection();
			// 向数据库中发送你的sql语句
			stat = connection.createStatement();
			// 获得所查询的结果，返回的是Resultset对象
			rs1 = stat.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs1;
	}
	public static int update(String sql) {
		try {
			connection = getConnection();
			ps = connection.prepareStatement(sql);
			rows = ps.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rows;
	}
	public int delete(String sql) {
		try {
			connection = getConnection();
			stat = connection.createStatement();
			rows = ps.executeUpdate(sql);
			return rows;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static void close() {
		try {
			if (rs1 != null) {
				rs1.close();
			}
			if (stat != null) {
				stat.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
		}
	}
}
